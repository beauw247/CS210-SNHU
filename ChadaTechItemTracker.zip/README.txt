CS210 - Week 7 Project: Corner Grocer
Author: Beau Welchel

This program analyzes item purchases from a grocery store log.

Menu Options:
1. Search for item frequency
2. Print all item frequencies
3. Print histogram of items
4. Exit program

Input File: InputTextItemTracker.txt
Output Backup File: frequency.dat
